import { useEffect, useRef, useState } from "react";
import { Check } from "lucide-react";

const steps = [
  {
    step: "Step 01",
    title: "Register Online",
    desc:
      "Sign up your child easily and choose camp sessions quickly through our simple online form.",
  },
  {
    step: "Step 02",
    title: "Prepare for Camp",
    desc:
      "Receive a welcome packet with schedules, packing lists, important reminders, and essential info.",
  },
  {
    step: "Step 03",
    title: "Join the Adventure",
    desc:
      "Campers arrive ready to play, explore, and make new friends with guidance from our caring staff.",
  },
  {
    step: "Step 04",
    title: "Share the Experience",
    desc:
      "Follow photos and updates daily and celebrate your camper’s summer achievements together.",
  },
];

export default function HowItWorks() {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );

    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={ref}
      className="relative py-28 text-white overflow-hidden"
    >
      {/* 🔥 BACKGROUND VIDEO */}
      <video
        className="absolute inset-0 h-full w-full object-cover"
        autoPlay
        loop
        muted
        playsInline
      >
        <source src="/bg-video.mp4" type="video/mp4" />
      </video>

      {/* 🔥 DARK OVERLAY (keeps text readable) */}
      <div className="absolute inset-0 "></div>

      {/* ✅ CONTENT (UNCHANGED) */}
      <div className="relative z-10 mx-auto max-w-7xl px-6 text-center">
        {/* Tag */}
        <span
          className={`inline-block -rotate-6 rounded-md bg-yellow-400 px-4 py-1 text-xs font-bold text-black mb-4 ${
            visible ? "animate-popIn" : "opacity-0"
          }`}
        >
          HOW IT WORKS
        </span>

        {/* Heading */}
        <h2
          className={`font-heading text-[2.6rem] md:text-[3.2rem] font-extrabold leading-tight ${
            visible ? "animate-popIn" : "opacity-0"
          }`}
        >
          From Registration to
          <br />
          Adventure Journey
        </h2>

        {/* Timeline */}
        <div className="relative mt-16">
          {/* Line */}
          <div className="absolute top-4 left-0 right-0 h-[2px] bg-green-700"></div>

          {/* Steps */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-10 relative">
            {steps.map((item, i) => (
              <div
                key={i}
                className={`text-left ${
                  visible ? "animate-fadeUp" : "opacity-0"
                }`}
                style={{ animationDelay: `${i * 0.15}s` }}
              >
                {/* Dot */}
                <div className="relative z-10 mb-6 flex items-center">
                  <div
                    className={`flex h-8 w-8 items-center justify-center rounded-full ${
                      i < 3
                        ? "bg-lime-400 text-black"
                        : "bg-green-700 text-green-300"
                    }`}
                  >
                    {i < 3 ? <Check size={16} /> : null}
                  </div>
                </div>

                {/* Text */}
                <p className="text-sm text-green-300">{item.step}</p>
                <h4 className="mt-1 font-semibold">{item.title}</h4>
                <p className="mt-2 text-sm text-green-100">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <button
          className={`mt-16 rounded-full bg-orange-500 px-10 py-4 text-sm font-semibold text-white transition hover:bg-orange-600 ${
            visible ? "animate-popIn" : "opacity-0"
          }`}
        >
          Register Now
        </button>
      </div>
    </section>
  );
}
