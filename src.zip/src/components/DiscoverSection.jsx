export default function DiscoverSection() {
  return (
    <section className="relative bg-[#F3FAE8] py-28 overflow-hidden">
      {/* Floating circles */}
      {/* Top Left */}
      <img
        src="https://images.unsplash.com/photo-1705829512772-e0ba43a72dd9?q=80&w=1331&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
        className="absolute left-16 top-24 h-50 w-50 rounded-full object-cover"
        alt=""
      />

      {/* Top Right */}
      <img
        src="https://images.unsplash.com/photo-1727994962758-ac74defe0bb9?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MzF8fHdhdGVycGFya3xlbnwwfHwwfHx8MA%3D%3D"
        className="absolute right-54 top-24 h-50 w-50 rounded-full object-cover"
        alt=""
      />

      {/* Middle Right */}
      <img
        src="https://images.unsplash.com/photo-1706843540950-04827b1aa919?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mzl8fHdhdGVycGFya3xlbnwwfHwwfHx8MA%3D%3D"
        className="absolute right-10 top-1/2 h-40 w-40 -translate-y-1/2 rounded-full object-cover"
        alt=""
      />

      {/* Bottom Right */}
      <img
        src="https://images.unsplash.com/photo-1628950992435-9f3acaf1adbe?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8d2F0ZXJwYXJrfGVufDB8fDB8fHww"
        className="absolute right-54 bottom-2 h-50 w-50 rounded-full object-cover"
        alt=""
      />

      {/* Bottom Left */}
      <img
        src="https://plus.unsplash.com/premium_photo-1661575521274-b5bfae7e3af4?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTd8fHdhdGVycGFya3xlbnwwfHwwfHx8MA%3D%3D"
        className="absolute left-24 bottom-5 h-50 w-50 rounded-full object-cover"
        alt=""
      />

      {/* Decorative leaves */}
      <span className="absolute right-[35%] top-[35%] h-3 w-6 rotate-12 rounded-full bg-green-400"></span>
      <span className="absolute right-[33%] top-[37%] h-3 w-6 rotate-[-20deg] rounded-full bg-green-400"></span>

      {/* Content */}
      <div className="relative z-10 mx-auto max-w-4xl px-6 text-center">
        <h2 className="text-[2.5rem] leading-tight font-extrabold uppercase text-[#1F4D2B] md:text-[3.2rem]">
          Discovering Wonder,
          <br />
          Friendship, Adventure,
          <br />
          And Life-Long Memories
        </h2>

        <p className="mx-auto mt-6 max-w-2xl text-sm text-[#3F5F4C] md:text-base">
          Every moment is an opportunity to explore, connect, and create
          memories that last a lifetime, while making friends, discovering new
          passions, and embracing the beauty of nature.
        </p>

        <button className="mt-10 rounded-full bg-orange-500 px-8 py-4 text-sm font-semibold text-white transition hover:bg-orange-600">
          Explore Our Programs
        </button>
      </div>
    </section>
  );
}
