import { Smile, Lightbulb } from "lucide-react";

export default function AboutSection() {
  return (
    <section className="bg-[#0047AB] py-28">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-14 items-center">

          {/* LEFT IMAGE */}
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1629834598512-77a443808b73?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
              className="h-[520px] w-full rounded-[40px] object-cover"
              alt=""
            />
          </div>

          {/* CENTER CONTENT */}
          <div className="text-white">
            {/* Tag */}
            <span className="inline-block mb-4 -rotate-6 rounded-md bg-yellow-400 px-4 py-1 text-xs font-bold text-black">
              ABOUT US
            </span>

            {/* Heading */}
            <h2 className="font-heading text-[2.8rem] leading-tight md:text-[3.4rem] font-extrabold">
              A Welcoming <br />
              Natural Haven <br />
              Close To Home
            </h2>

            {/* Description */}
            <p className="mt-5 max-w-md text-sm text-green-100">
              At Starlight Camp, each day is an adventure of laughter and
              friendship. Campers gain confidence, joy, new skills, and
              unforgettable summer memories.
            </p>

            <hr className="my-8 border-green-700" />

            {/* Features */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="flex gap-4">
                <Smile className="h-8 w-8 text-green-300" />
                <div>
                  <h4 className="font-semibold">
                    Safe and supportive space
                  </h4>
                  <p className="text-sm text-green-100">
                    Our team ensures campers feel safe, welcome, and encouraged
                    to shine.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <Lightbulb className="h-8 w-8 text-green-300" />
                <div>
                  <h4 className="font-semibold">
                    Endless Adventures
                  </h4>
                  <p className="text-sm text-green-100">
                    Exciting outdoor challenges and creative activities await
                    at every turn.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT IMAGE */}
          <div className="relative hidden lg:block">
            {/* Tag */}
            <span className="absolute -top-4 right-10 rotate-6 rounded-md bg-lime-400 px-3 py-1 text-xs font-bold text-black">
              NATURE
            </span>

            <img
              src="https://plus.unsplash.com/premium_photo-1661378818245-0fe1239e5bdc?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
              className="h-[420px] w-full rounded-[40px] object-cover"
              alt=""
            />
          </div>

        </div>
      </div>
    </section>
  );
}
