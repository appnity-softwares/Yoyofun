import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import DiscoverSection from "./components/DiscoverSection";
import AboutSection from "./components/AboutSection";
import HowItWorks from "./components/HowItWorks";

export default function App() {
  return (
    <>
      <Navbar />
      <Hero />
      <DiscoverSection/>
    
      <AboutSection />
      <HowItWorks/>
    </>
  );
}
